﻿using UnityEngine;

public class Player : MonoBehaviour
{
    public Board board { get; private set; }
    public TetrominoData data { get; private set; }
    public Vector3Int[] cells { get; private set; }
    public Vector3Int position { get; private set; }
    public int rotationIndex { get; private set; }

    public float moveDelay = 0.1f;

    private float moveTime;

    public void Initialize(Board board, Vector3Int position, TetrominoData data)
    {
        this.data = data;
        this.board = board;
        this.position = position;

        rotationIndex = 0;
        moveTime = Time.time + moveDelay;

        if (cells == null)
        {
            cells = new Vector3Int[data.cells.Length];
        }

        for (int i = 0; i < cells.Length; i++)
        {
            cells[i] = (Vector3Int)data.cells[i];
        }
    }

    public void CapturePiece(int tetrominonewLength, int newLength, Piece piece)
    {
        Vector3Int[] oldcells = cells;
        Vector2Int[] olddatacells = data.cells;

        /*for (int i = 0; i < cells.Length; i++)
        {
            Debug.Log(cells[i]);
        }*/

        cells = new Vector3Int[newLength];

        for (int i = 0; i < oldcells.Length; i++)
        {
            cells[i] = oldcells[i];
            cells[i + (newLength - oldcells.Length)]  = oldcells[i] + new Vector3Int(0, 1, 0);
        }

        /*for (int i = 0; i < cells.Length; i++)
        {
            Debug.Log(cells[i]);
        }*/
    }

    //keyboard input 2
    private void Update()
    {
        board.ClearPlayer(this);

        // Allow the player to hold movement keys but only after a move delay
        // so it does not move too fast
        if (Time.time > moveTime)
        {
            HandleMoveInputs();
        }

        board.SetPlayer(this);
    }

    //keyboard input
    private void HandleMoveInputs()
    {
        // Left/right movement
        if (Input.GetKey(KeyCode.A))
        {
            Move(Vector2Int.left);
        }
        else if (Input.GetKey(KeyCode.D))
        {
            Move(Vector2Int.right);
        }
    }

    //gerakin
    private bool Move(Vector2Int translation)
    {
        Vector3Int newPosition = position;
        newPosition.x += translation.x;
        newPosition.y += translation.y;

        bool valid = board.IsValidPositionPlayer(this, newPosition);

        // Only save the movement if the new position is valid
        if (valid)
        {
            position = newPosition;
            moveTime = Time.time + moveDelay;
            //lockTime = 0f; // reset
        }

        return valid;
    }
}
